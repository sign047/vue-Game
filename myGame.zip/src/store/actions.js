import Vue from 'vue'

let timer,
	statusHandler = {
		PLAYING(commit) {
			timer = setInterval(function() {
				commit('counting');
			}, 1000);
		},
		PASS(commit) {
			clearInterval(timer);
			commit('updateHighestSpeed');
		}
	};

export default {
	updateStatus({ commit }, status) {
		commit('updateStatus', status);
		statusHandler[status] && statusHandler[status](commit);
	},
	flip({ commit }, card) {
		commit('flip', card);
	},
	match({ commit }) {
		commit('match')
	},
	back({ commit }, data) {
		commit('back', data);
	},
	getRank({ commit }, url) {
		Vue.axios.post(url,{
			name:'aaaa',
			code:22
		})
		.then((res) => {
			commit('getRank', res.data.data)
		})
		.catch((err) => {
			alert(err)
		})
	}

}
