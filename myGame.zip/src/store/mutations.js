export default{
	updateStatus(state,st){
		state.status=st;
	},
	counting(state){
		state.time++;
	},		
	updateHighestSpeed(state) {
        if (!localStorage.getItem('highestSpeed')) {
            return localStorage.setItem('highestSpeed', state.time);
        }
        if (localStorage.getItem('highestSpeed') > state.time) {
            return localStorage.setItem('highestSpeed', state.time);
        }
   },
   match(state){
   		state.unMached--;
   },
   back(state,arr){
   		arr.forEach((item) => item.flipped=false);
   },
   flip(state,card){
   	 let mark= state.list.find((val) => val.num==card.num);
   	 mark.flipped=true;
   },
   getRank(state,data){
   		state.rank=data;
   }
}
